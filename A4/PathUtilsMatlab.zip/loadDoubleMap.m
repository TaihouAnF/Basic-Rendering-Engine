% Load double precision map produced by the path tracer

f=fopen('MyRender.ppm.pfm','r');
fgets(f);
fgets(f);
fgets(f);
[im]=fread(f,[inf],'double');
fclose(f);
im3=reshape(im,[3 length(im)/3]);
sd=sqrt(length(im3(1,:)));
imt1=reshape(im3(1,:),[sd sd])';
imt2=reshape(im3(2,:),[sd sd])';
imt3=reshape(im3(3,:),[sd sd])';

imRGB=zeros([sd sd 3]);
imRGB(:,:,1)=imt1;
imRGB(:,:,2)=imt2;
imRGB(:,:,3)=imt3;

