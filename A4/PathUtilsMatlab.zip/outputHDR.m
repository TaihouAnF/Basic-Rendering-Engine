% This script will read the double precision image data output by the Path Tracer and
% output a .hdr High Dynamic Range image file for rendering using standard HDR tonemapping
% software.
%
% So far it only works on Matlab. The hdrwrite function used here has not yet been
% implemented in Octave.
%

im=readPFM('dummy.ppm.pfm');
hdrwrite(im,'PathTracer_output.hdr');
