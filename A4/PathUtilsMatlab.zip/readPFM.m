% Load double precision map produced by the path tracer
function [imT]=readPFM(name)
imT=[];

f=fopen(name,'r');
if (f>0)
 fgets(f);
 fgets(f);
 fgets(f);
 [im]=fread(f,[inf],'double');
 fclose(f);
 im3=reshape(im,[3 length(im)/3]);
 sd=sqrt(length(im3(1,:)));
 imt1=reshape(im3(1,:),[sd sd])';
 imt2=reshape(im3(2,:),[sd sd])';
 imt3=reshape(im3(3,:),[sd sd])';
 imT=zeros([size(imt1,1) size(imt1,2) 3]);
 imT(:,:,1)=imt1;
 imT(:,:,2)=imt2;
 imT(:,:,3)=imt3;
end;
